<?php

return [
    'addresses' => [
        'first_name' => 'First Name',
        'last_name' => 'Last Name',
        'address_1' => 'Address Line 1',
        'city' => 'City',
        'zip' => 'Postcode / ZIP',
        'country' => 'Country',
        'state' => 'State / Province',
    ],
];
