<?php

return [
    'index' => 'Index Coupons',
    'create' => 'Create Coupons',
    'edit' => 'Edit Coupons',
    'destroy' => 'Delete Coupons',
];
