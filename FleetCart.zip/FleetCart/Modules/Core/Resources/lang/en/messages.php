<?php

return [
    'the_given_data_was_invalid' => 'The given data was invalid.',
    'mail_is_not_configured' => 'Mail is not configured properly.',
];
