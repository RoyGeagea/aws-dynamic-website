<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Tag\\Providers\\TagServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Tag\\Providers\\TagServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);