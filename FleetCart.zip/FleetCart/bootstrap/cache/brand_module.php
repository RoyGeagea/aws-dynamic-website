<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Brand\\Providers\\BrandServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Brand\\Providers\\BrandServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);