<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Category\\Providers\\CategoryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Category\\Providers\\CategoryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);