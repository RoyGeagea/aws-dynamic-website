<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Media\\Providers\\MediaServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Media\\Providers\\MediaServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);